CREATE DATABASE caso1; 

CREATE TABLE departamento(
	nombre_departamento VARCHAR,
	id SERIAL PRIMARY KEY
);
CREATE TABLE trabajador (
	rut VARCHAR,
	nombre VARCHAR,
	direccion VARCHAR,
	id_departamento INT REFERENCES departamento(id),
	PRIMARY KEY(rut)
);

CREATE TABLE liquidacion(
	rut VARCHAR REFERENCES trabajador(rut),
	id SERIAL,
	drive VARCHAR,
	PRIMARY KEY(id)
);